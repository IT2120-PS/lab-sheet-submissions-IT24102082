setwd("C:\\Users\\Kaviya\\Desktop\\IT24102082")
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)
attach(Delivery_Times)

Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

hist_object <- hist(Delivery_Times$Delivery_Time_.minutes.,
                    breaks = seq(from = 20, to = 70, length.out = 10),
                    right = FALSE,
                    main = "Histogram of Delivery Times",
                    xlab = "Delivery Time (minutes)",
                    ylab = "Frequency",
                    col = "cornflowerblue")

# "The distribution of delivery times is approximately symmetric and unimodal, resembling a bell shape.
# The frequencies are highest in the middle range (around 35-45 minutes) and decrease towards the extremes."

frequencies <- hist_object$counts
class_boundaries <- hist_object$breaks 
cumulative_frequencies <- cumsum(frequencies)
ogive_data <- c(0, cumulative_frequencies)

plot(class_boundaries, ogive_data,
     type = "b",
     main = "Ogive for Delivery Times",
     xlab = "Delivery Time (Upper Class Boundary)",
     ylab = "Cumulative Frequency",
     ylim = c(0, max(ogive_data)),
     col = "red",
     pch = 19)