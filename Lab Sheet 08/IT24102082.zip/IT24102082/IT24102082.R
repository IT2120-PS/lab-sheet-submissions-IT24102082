setwd("C:/Users/IT24102082/Desktop/IT24102082")

laptop_data<-read.table("Exercise - LaptopsWeights.txt",header = TRUE)

attach(laptop_data)

pop_mean<-mean(Weight.kg.)
pop_sd<-sd(Weight.kg.)

print(paste("Population Mean: ", pop_mean))
print(paste("Population SD " , pop_sd))

sample<-c()
for(i in 1:25){
  s<-sample(Weight.kg.,size=6,replace = TRUE)
  sample<-cbind(sample, s)
}

sample_mean<-apply(sample,2,mean)
sample_sd<-apply(sample,2,sd)

print("Mean of the 25 sample: ")
print(sample_mean)
print("SD f the 25 sample: ")
print(sample_sd)

mean_of_the_sample_means<-mean(sample_mean)
sd_of_the_sample_means<-sd(sample_mean)

print(paste("Mean of the sample means: ", mean_of_the_sample_means))
print(paste("Sd of the sample means: ",sd_of_the_sample_means))

print(paste("The Mean of sample Means("
            ,round(mean_of_the_sample_means,4),
            ") is approximately equal to the Population Mean (",
            round(pop_mean,4),")."))

theoretical_se<-pop_sd/sqrt(6)
print(paste("The SD of sample Means ("
            ,round(sd_of_the_sample_means,4),
            ") is approximately equal to the Population SD / sqrt(n) ("
            ,round(theoretical_se,4),")."))
